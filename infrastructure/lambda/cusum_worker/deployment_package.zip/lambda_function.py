import json
import os
import logging
from datetime import datetime, timezone
import psycopg2
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# cusum_engine and cusum_state_manager must be bundled in the Lambda deployment zip
from cusum_state_manager import CUSUMStateManager
from cusum_engine import CUSUMTimeSeriesDetector, get_cold_start_params

sns_client = boto3.client('sns')


class PostgresDBWrapper:
    """Wrap raw psycopg2 connection for CUSUMStateManager compatibility."""
    def __init__(self, conn):
        self.conn = conn

    def query(self, sql, params=()):
        with self.conn.cursor() as cur:
            cur.execute(sql, params)
            if cur.description:
                return cur.fetchall()
            return []

    def execute(self, sql, params=()):
        with self.conn.cursor() as cur:
            cur.execute(sql, params)
            self.conn.commit()
            return cur


def get_db_connection():
    db_url = os.environ.get("SUPABASE_DB_URL")
    if not db_url:
        logger.error("SUPABASE_DB_URL missing from environment variables")
        return None
    return psycopg2.connect(db_url)


# =============================================================================
# Lambda Handler – Supports BOTH Supabase Webhook AND SQS payloads
# =============================================================================

def lambda_handler(event, context):
    """
    AWS Lambda entry point.

    Supported triggers:
      1. Supabase Database Webhook (via Lambda Function URL / API Gateway)
         Payload: { "type": "INSERT", "table": "transactions", "record": { ... } }
      2. AWS SQS (legacy EventBridge path)
         Payload: { "Records": [{ "body": "..." }] }
    """
    logger.info(f"Received event: {json.dumps(event)}")

    conn = get_db_connection()
    if not conn:
        return {"statusCode": 500, "body": "Database connection failed"}

    try:
        db = PostgresDBWrapper(conn)
        manager = CUSUMStateManager(db)

        # ── Detect payload format ──────────────────────────────────────────
        # Path A: Supabase Webhook (HTTP POST via Function URL / API Gateway)
        if "body" in event and isinstance(event["body"], str):
            payload = json.loads(event["body"])
            record = payload.get("record", payload)
            _process_record(manager, db, record)

        elif "record" in event:
            # Direct invocation with Supabase-style JSON
            _process_record(manager, db, event["record"])

        # Path B: SQS Records (legacy EventBridge → SQS path)
        elif "Records" in event:
            for sqs_record in event["Records"]:
                body = json.loads(sqs_record.get("body", "{}"))
                detail = body.get("detail", body)
                _process_record(manager, db, detail)

        else:
            logger.warning("Unknown event format, attempting direct parse")
            _process_record(manager, db, event)

        return {"statusCode": 200, "body": "OK"}

    except Exception as e:
        logger.error(f"Lambda execution error: {e}")
        return {"statusCode": 500, "body": str(e)}
    finally:
        conn.close()


# =============================================================================
# Core Processing (shared by all trigger paths)
# =============================================================================

def _process_record(manager, db, record: dict):
    """Extract fields from a transaction record and run CUSUM analysis.

    Cold-start aware: when a jar has fewer than 3 days of data in the
    7-day window, CUSUM is skipped entirely to avoid false alarms from an
    unstable σ.  For n = 3–6 days, σ is inflated by a confidence_factor
    to widen the detection threshold until the window is fully warm.
    """
    user_id   = record.get("user_id")
    jar_id    = record.get("jar_id")
    amount    = record.get("amount")
    direction = record.get("direction", "debit")

    if not all([user_id, jar_id, amount]):
        logger.warning(f"Skipping record – missing fields: {record}")
        return

    amount = float(amount)

    # ── 1. Bypass CUSUM cho khoản thu (Idle Money Detection) ─────────────
    if direction == "credit":
        logger.info(f"Received CREDIT of {amount:,.0f} VND for {user_id}. Skipping CUSUM.")

        # Tiêu chuẩn 1: Là khoản vào định kỳ?
        is_regular = manager.is_regular_inflow(user_id, amount)

        # Tiêu chuẩn 2: Vượt chi tiêu trung bình tháng?
        baseline = manager.get_baseline_stats(user_id, jar_id, lookback_days=7)
        monthly_spend_avg = baseline["mean"] * 30
        exceeds_avg_spend = amount > monthly_spend_avg

        # Tiêu chuẩn 3: Tổng số dư thực tế > Chi tiêu trung bình tháng?
        total_balance = manager.get_total_available_balance(user_id)
        has_surplus = total_balance > monthly_spend_avg

        # Tiêu chuẩn 4: Chống Spam (3 ngày 1 lần)
        can_alert = manager.can_send_idle_money_alert(user_id, cooldown_days=3)

        if is_regular and exceeds_avg_spend and has_surplus and can_alert:
            _handle_idle_money_alert(db, user_id, jar_id, amount, monthly_spend_avg, total_balance)

        return  # Không cập nhật CUSUM state cho khoản thu

    # ── 2. Determine cold-start phase (for DEBIT) ────────────────────────

    n_days   = manager.get_days_with_data(user_id, jar_id, window_days=7)
    baseline = manager.get_baseline_stats(user_id, jar_id, lookback_days=7)

    sigma_raw  = baseline["sigma"] * 2.6 if baseline["sigma"] > 0 else 1_500_000
    mean_raw   = baseline["mean"]

    jar_budget = manager.get_jar_allocated_amount(user_id, jar_id)
    cold       = get_cold_start_params(n_days, sigma_raw, jar_budget)

    # ── 3. n ≤ 2: skip CUSUM, only sanity-check budget ───────────────────
    if cold["skip_cusum"]:
        logger.info(
            f"[COLD-START] n={n_days} days – CUSUM skipped for "
            f"user={user_id} jar={jar_id}"
        )
        sanity = cold.get("sanity_limit")
        if sanity and sanity > 0 and amount > sanity:
            logger.warning(
                f"[COLD-START SANITY] amount={amount:,.0f} > 50% budget "
                f"({jar_budget:,.0f}) for user={user_id} jar={jar_id}"
            )
            _handle_alert(db, user_id, jar_id, {
                "type": "sudden_spike",
                "severity": "medium",
                "recommendation": (
                    f"⚠️ Giao dịch {amount:,.0f} VND vượt 50% ngân sách jar "
                    f"({jar_budget:,.0f} VND) ngay từ đầu chu kỳ. Cần kiểm tra."
                ),
            })
        return  # Do NOT update CUSUM state

    # ── 4. n ≥ 3: run CUSUM with confidence-factor-adjusted sigma ────────
    sigma_eff   = cold["sigma_effective"]   # sigma_raw * confidence_factor
    weekly_mean = mean_raw * 7 if mean_raw > 0 else 10_000_000

    state_dict = manager.load_state(user_id, jar_id)
    detector = CUSUMTimeSeriesDetector(
        reference_mean=weekly_mean,
        sigma=sigma_eff,
        k_factor=0.5,
        h_factor=5.0,
        z_score_threshold=4.0,
    )
    detector.cumsum_pos       = state_dict["cumsum_pos"]
    detector.cumsum_neg       = state_dict["cumsum_neg"]
    detector.transaction_count = state_dict["transaction_count"]

    timestamp = datetime.now(timezone.utc).isoformat()
    new_state, drift_detected, anomaly_info = detector.update_series(amount, timestamp)

    logger.info(
        f"[CUSUM] user={user_id} jar={jar_id} n_days={n_days} "
        f"cf={cold['confidence_factor']} sigma_eff={sigma_eff:.0f} "
        f"S+={new_state.cumsum_pos:.0f} drift={drift_detected}"
    )

    # ── 5. Persist updated state ─────────────────────────────────────────
    manager.save_state(
        user_id, jar_id,
        cumsum_pos=new_state.cumsum_pos,
        cumsum_neg=new_state.cumsum_neg,
        reference_mean=weekly_mean,
        reference_sigma=sigma_eff,
        drift_detected=drift_detected,
        transaction_count=new_state.transaction_count,
    )

    # ── 6. Alert pathway ──────────────────────────────────────────────────
    if drift_detected or anomaly_info.get("type") == "sudden_spike":
        _handle_alert(db, user_id, jar_id, anomaly_info)



# =============================================================================
# Alert: DB notification + AWS SNS
# =============================================================================

def _handle_alert(db, user_id, jar_id, anomaly_info):
    _anomaly = anomaly_info.get("type", "other")
    if "up" in _anomaly or "spike" in _anomaly:
        mapped_type = "upward_drift"
    elif "down" in _anomaly:
        mapped_type = "downward_drift"
    else:
        mapped_type = "other"

    trace_id = f"auto_drift_{int(datetime.now().timestamp())}"

    # ── Insert into tier1_notifications ─────────────────────────────────
    try:
        db.execute(
            """
            INSERT INTO tier1_notifications
                (user_id, jar_id, anomaly_type, title, detail, severity, trace_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (
                user_id, jar_id, mapped_type,
                "Cảnh báo CUSUM: Bất thường chi tiêu!",
                anomaly_info.get("recommendation", "Kiểm tra lại giao dịch."),
                anomaly_info.get("severity", "medium"),
                trace_id,
            ),
        )
        logger.info(f"🚨 Notification saved for {user_id}")
    except Exception as e:
        logger.error(f"Failed to save notification: {e}")

    # ── Publish to AWS SNS ──────────────────────────────────────────────
    sns_topic_arn = os.environ.get("SNS_TOPIC_ARN")
    if sns_topic_arn:
        try:
            sns_client.publish(
                TopicArn=sns_topic_arn,
                Subject="Fintech Tier 1 Alert",
                Message=f"🚨 Cảnh báo CUSUM: {anomaly_info.get('recommendation')}",
            )
            logger.info("📡 Published to SNS")
        except Exception as e:
            logger.error(f"SNS publish failed: {e}")


def _handle_idle_money_alert(db, user_id, jar_id, amount, monthly_spend_avg, total_balance):
    """Ghi nhận thông báo Idle Money (Tiền nhàn rỗi) và gửi SNS."""
    trace_id = f"idle_money_{int(datetime.now().timestamp())}"
    title = "Khoản tiền nhàn rỗi? Lên kế hoạch ngay!"
    detail = (
        f"Bạn vừa nhận khoản thu định kỳ {amount:,.0f} VND "
        f"(lớn hơn chi tiêu trung bình {monthly_spend_avg:,.0f} VND/tháng). "
        f"Hiện tại bạn đang có {total_balance:,.0f} VND nhàn rỗi. "
        f"Hãy tạo hũ Tiết Kiệm/Đầu Tư để tối ưu dòng tiền nhé!"
    )

    try:
        db.execute(
            """
            INSERT INTO tier1_notifications
                (user_id, jar_id, anomaly_type, title, detail, severity, trace_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (user_id, jar_id, "other", title, detail, "low", trace_id)
        )
        logger.info(f"💡 Idle money notification saved for {user_id}")
    except Exception as e:
        logger.error(f"Failed to save idle money notification: {e}")

    sns_topic_arn = os.environ.get("SNS_TOPIC_ARN")
    if sns_topic_arn:
        try:
            sns_client.publish(
                TopicArn=sns_topic_arn,
                Subject="Fintech Idle Money Alert",
                Message=detail,
            )
        except Exception as e:
            logger.error(f"SNS idle money publish failed: {e}")
